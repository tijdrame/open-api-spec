# Mobile

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**networkType** | [**NetworkTypeEnum**](#NetworkTypeEnum) |  |  [optional]

<a name="NetworkTypeEnum"></a>
## Enum: NetworkTypeEnum
Name | Value
---- | -----
_4G | &quot;4G&quot;
_5G | &quot;5G&quot;
