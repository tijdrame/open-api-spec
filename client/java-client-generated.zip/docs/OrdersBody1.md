# OrdersBody1

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**products** | [**List&lt;Product&gt;**](Product.md) |  |  [optional]
**address** | [**Address**](Address.md) |  |  [optional]
