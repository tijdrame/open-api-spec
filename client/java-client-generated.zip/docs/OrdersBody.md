# OrdersBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**orderId** | **Integer** |  |  [optional]
**products** | [**List&lt;Product&gt;**](Product.md) |  |  [optional]
**address** | [**Address**](Address.md) |  |  [optional]
