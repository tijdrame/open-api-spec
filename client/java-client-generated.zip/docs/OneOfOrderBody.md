# OneOfOrderBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**products** | **OneOfoneOfOrderBodyProducts** |  | 
**address** | [**Address**](Address.md) |  | 
