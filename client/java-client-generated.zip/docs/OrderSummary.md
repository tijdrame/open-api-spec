# OrderSummary

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**products** | [**List&lt;Product&gt;**](Product.md) |  |  [optional]
