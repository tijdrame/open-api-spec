# Product

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**productId** | **Integer** |  |  [optional]
**name** | **String** |  |  [optional]
**price** | **Float** |  |  [optional]
**categoryName** | **String** |  |  [optional]
**releaseDate** | [**LocalDate**](LocalDate.md) |  |  [optional]
**quantity** | **Integer** | ***Quantity*** represents &#x60;stock&#x60; value when  this field is send to EasyShop &lt;u&gt;xxx &lt;/ul&gt;  |  [optional]
