# Laptop

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ram** | [**RamEnum**](#RamEnum) |  | 

<a name="RamEnum"></a>
## Enum: RamEnum
Name | Value
---- | -----
_8_GB | &quot;8 GB&quot;
_16_GB | &quot;16 GB&quot;
_32_GB | &quot;32 GB&quot;
