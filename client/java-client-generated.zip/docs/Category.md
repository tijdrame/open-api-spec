# Category

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**categoryId** | **Integer** |  |  [optional]
**name** | **String** |  |  [optional]
